/* ── Nav + Hero — v3 Abstract + Animated ── */

function NavBar() {
  const [scrolled, setScrolled] = React.useState(false);
  const [mobileOpen, setMobileOpen] = React.useState(false);
  React.useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 60);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const links = [
    ['About', '#about'], ['Projects', '#projects'], ['Skills', '#skills'],
    ['Research', '#research'], ['GitHub', '#github'], ['Contact', '#contact'],
  ];

  return (
    <React.Fragment>
      <nav className={`nav ${scrolled ? 'scrolled' : ''}`}>
        <div className="nav-logo">PD<span className="dot">.</span></div>
        <ul className="nav-links">
          {links.map(([label, href]) => (
            <li key={href}><a href={href}>{label}</a></li>
          ))}
        </ul>
        <button className="nav-mobile-btn" onClick={() => setMobileOpen(!mobileOpen)} aria-label="Menu">
          <span className={`hamburger ${mobileOpen ? 'open' : ''}`}>
            <span></span><span></span><span></span>
          </span>
        </button>
      </nav>

      {/* Mobile Drawer */}
      <div className={`mobile-drawer ${mobileOpen ? 'open' : ''}`}>
        <div className="mobile-drawer-content">
          {links.map(([label, href], i) => (
            <a
              key={href} href={href}
              className="mobile-drawer-link"
              style={{transitionDelay: mobileOpen ? `${0.05 + i * 0.05}s` : '0s'}}
              onClick={() => setMobileOpen(false)}
            >
              <span className="mobile-drawer-num">{String(i + 1).padStart(2, '0')}</span>
              {label}
            </a>
          ))}
          <div className="mobile-drawer-footer">
            <a href={PERSONAL.github} target="_blank" rel="noopener">GitHub</a>
            <a href={PERSONAL.linkedin} target="_blank" rel="noopener">LinkedIn</a>
            <a href={PERSONAL.twitter} target="_blank" rel="noopener">X</a>
          </div>
        </div>
      </div>
    </React.Fragment>
  );
}

/* ── Animated Text Reveal ── */
function RevealText({ text, tag = 'span', className = '', delay = 0, charMode = false }) {
  const [ref, visible] = useScrollReveal(0.2);
  const Tag = tag;

  if (charMode) {
    const chars = text.split('');
    return (
      <Tag ref={ref} className={className} style={{display:'inline-block'}}>
        {chars.map((ch, i) => (
          <span key={i} style={{
            display: 'inline-block',
            opacity: visible ? 1 : 0,
            transform: visible ? 'translateY(0) rotateX(0)' : 'translateY(100%) rotateX(-80deg)',
            transition: `all 0.6s cubic-bezier(0.16,1,0.3,1) ${delay + i * 0.03}s`,
            transformOrigin: 'bottom',
          }}>
            {ch === ' ' ? '\u00A0' : ch}
          </span>
        ))}
      </Tag>
    );
  }

  const words = text.split(' ');
  return (
    <Tag ref={ref} className={className} style={{display:'flex', flexWrap:'wrap', gap:'0 0.3em'}}>
      {words.map((word, i) => (
        <span key={i} style={{overflow:'hidden', display:'inline-block'}}>
          <span style={{
            display: 'inline-block',
            opacity: visible ? 1 : 0,
            transform: visible ? 'translateY(0)' : 'translateY(110%)',
            transition: `all 0.7s cubic-bezier(0.16,1,0.3,1) ${delay + i * 0.05}s`,
          }}>
            {word}
          </span>
        </span>
      ))}
    </Tag>
  );
}

/* ── Rotating Titles ── */
function RotatingTitle() {
  const titles = ['AI Engineer', 'Full-Stack Dev', 'ML Researcher', 'Hackathon Winner', 'IEEE Published'];
  const [index, setIndex] = React.useState(0);
  const [show, setShow] = React.useState(true);

  React.useEffect(() => {
    const interval = setInterval(() => {
      setShow(false);
      setTimeout(() => {
        setIndex(prev => (prev + 1) % titles.length);
        setShow(true);
      }, 400);
    }, 2800);
    return () => clearInterval(interval);
  }, []);

  return (
    <span className="rotating-title-wrap">
      <span className={`rotating-title ${show ? 'show' : ''}`}>{titles[index]}</span>
    </span>
  );
}

function HeroSection() {
  const [loaded, setLoaded] = React.useState(false);
  React.useEffect(() => { setTimeout(() => setLoaded(true), 300); }, []);

  const enterStyle = (delay) => ({
    opacity: loaded ? 1 : 0,
    transform: loaded ? 'translateY(0)' : 'translateY(60px)',
    transition: `opacity 1.2s cubic-bezier(0.16,1,0.3,1) ${delay}s, transform 1.2s cubic-bezier(0.16,1,0.3,1) ${delay}s`,
  });

  return (
    <section className="hero" id="hero">
      <div className="hero-grain"></div>

      {/* Abstract geometric elements */}
      <div className="hero-geo">
        <div className="geo-circle geo-1"></div>
        <div className="geo-circle geo-2"></div>
        <div className="geo-line geo-3"></div>
        <div className="geo-line geo-4"></div>
        <div className="geo-dot geo-5"></div>
        <div className="geo-dot geo-6"></div>
        <div className="geo-dot geo-7"></div>
      </div>

      <div className="hero-top" style={enterStyle(0.3)}>
        <div className="hero-meta">
          Based in Ahmedabad, India<br />
          B.Tech AI/ML · Nirma University<br />
          CGPA 8.85 / 10.0
        </div>
        <div className="hero-status">
          <span className="status-dot"></span>
          Available for opportunities
        </div>
      </div>

      <div className="hero-name-block">
        <h1 className="hero-name">
          <span className="split" style={enterStyle(0.15)}>Priyan<span className="accent-char">s</span>hu</span>
          <span className="split outline" style={enterStyle(0.3)}>Doshi</span>
        </h1>
        <div className="hero-role" style={enterStyle(0.5)}>
          <span className="hero-role-static">I'm a</span>
          <RotatingTitle />
        </div>
      </div>

      <div className="hero-bottom">
        <p className="hero-tagline" style={enterStyle(0.55)}>
          {PERSONAL.tagline}
        </p>
        <a href="#projects" className="hero-scroll-cta" style={enterStyle(0.65)}>
          <span className="line"></span>
          Scroll to explore
        </a>
      </div>
    </section>
  );
}

function MarqueeStrip() {
  return (
    <div className="marquee-strip">
      <div className="marquee-track">
        {[...MARQUEE_ITEMS, ...MARQUEE_ITEMS].map((item, i) => (
          <span className="marquee-item" key={i}>{item}</span>
        ))}
      </div>
    </div>
  );
}

/* ── Stat Counter with animation ── */
function StatCounter({ value, suffix = '', label, decimals = 0 }) {
  const [ref, val] = useCounter(value, 2200, decimals);
  return (
    <div className="stat-counter" ref={ref}>
      <div className="stat-val">{val}{suffix}</div>
      <div className="stat-label">{label}</div>
    </div>
  );
}

function StatsStrip() {
  const [ref, visible] = useScrollReveal(0.2);
  return (
    <div className="stats-strip" ref={ref}>
      <div className={`stats-strip-inner reveal ${visible ? 'visible' : ''}`}>
        <StatCounter value={20} suffix="+" label="Projects" />
        <div className="stats-divider"></div>
        <StatCounter value={1} suffix="" label="IEEE Paper" />
        <div className="stats-divider"></div>
        <StatCounter value={8.85} suffix="" label="CGPA" decimals={2} />
        <div className="stats-divider"></div>
        <StatCounter value={200} suffix="+" label="LC Problems" />
      </div>
    </div>
  );
}

Object.assign(window, { NavBar, HeroSection, MarqueeStrip, StatsStrip, RevealText });
