/* ── Main App v3 ── */

function App() {
  return (
    <React.Fragment>
      <NavBar />
      <HeroSection />
      <MarqueeStrip />
      <StatsStrip />
      <AboutSection />
      <ProjectsSection />
      <SkillsSection />
      <ResearchSection />
      <GitHubSection />
      <AchievementsSection />
      <ContactSection />
      <Footer />
    </React.Fragment>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
